self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bbe6d7c956e405d664f59e0a95375dea",
    "url": "./index.html"
  },
  {
    "revision": "95d6a780c5beecc8ff4e",
    "url": "./static/css/main.e68df73e.chunk.css"
  },
  {
    "revision": "fdaa4bfdc1a55d7dce2d",
    "url": "./static/js/2.2400b5ac.chunk.js"
  },
  {
    "revision": "6adce59638ff1f12aa03e688a4fb1552",
    "url": "./static/js/2.2400b5ac.chunk.js.LICENSE"
  },
  {
    "revision": "95d6a780c5beecc8ff4e",
    "url": "./static/js/main.27d1968c.chunk.js"
  },
  {
    "revision": "fa4fe069a9092b202ce7",
    "url": "./static/js/runtime-main.b03d6a54.js"
  },
  {
    "revision": "0ad99aa2e39ccec9821a37d5db1f429c",
    "url": "./static/media/JavscriptClock.0ad99aa2.gif"
  },
  {
    "revision": "f47749476f2656851187a3eb1bf8cb90",
    "url": "./static/media/clothingStore.f4774947.png"
  },
  {
    "revision": "61da4c0c8f3baaff61a33efb1c7ba2c3",
    "url": "./static/media/corefactors.61da4c0c.jpg"
  },
  {
    "revision": "c19b2da8f22331dc00d3cd15b79ae737",
    "url": "./static/media/emailchips.c19b2da8.gif"
  },
  {
    "revision": "1d630172625c707f736c91fc7b146912",
    "url": "./static/media/facerecognition.1d630172.png"
  },
  {
    "revision": "486eb462788c4b481c91f7e86a8efd49",
    "url": "./static/media/freelance.486eb462.jpg"
  },
  {
    "revision": "dce55be8afb99946b769e8cfefa10115",
    "url": "./static/media/landing-page.dce55be8.png"
  },
  {
    "revision": "c93a7f6be10a5222c9057b608b556b68",
    "url": "./static/media/portfolio.c93a7f6b.png"
  },
  {
    "revision": "2938897d9371143f62c9d793bf282d35",
    "url": "./static/media/robotapp.2938897d.png"
  }
]);